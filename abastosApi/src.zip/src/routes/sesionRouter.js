const sesionRouter = require("express").Router();
const sesion = require("../controllers/sesionController");

sesionRouter.get("/all", sesion.getAllSesiones);
sesionRouter.get("/:id", sesion.getSesionById);
sesionRouter.get("/categoria/:id_categoria", sesion.getSesionesByCategoria);
sesionRouter.post("/create", sesion.createSesion);
sesionRouter.delete("/delete/:id", sesion.deleteSesion);

module.exports = sesionRouter;
