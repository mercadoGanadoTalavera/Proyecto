const sesionService = require("../services/sesionService");

const getAllSesiones = async (req, res) => {
    try {
        const sesiones = await sesionService.getAllSesiones();
        res.status(200).json(sesiones);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const getSesionById = async (req, res) => {
    try {
        const sesion = await sesionService.getSesionById(req.params.id);
        sesion
            ? res.status(200).json(sesion)
            : res.status(404).json({ message: "Sesión no encontrada" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const getSesionesByCategoria = async (req, res) => {
    try {
        const sesiones = await sesionService.getSesionesByCategoria(req.params.id_categoria);
        res.status(200).json(sesiones);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const createSesion = async (req, res) => {
    try {
        const sesion = await sesionService.createSesion(req.body);
        res.status(201).json(sesion);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const deleteSesion = async (req, res) => {
    try {
        const result = await sesionService.deleteSesion(req.params.id);
        res.status(200).json({ message: result });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

module.exports = {
    getAllSesiones,
    getSesionById,
    getSesionesByCategoria,
    createSesion,
    deleteSesion
};
