const Sesion = require("../database/models/Sesion");
const Categoria = require("../database/models/Categoria");

// Obtener todas las sesiones
const getAllSesiones = async () => {
    return await Sesion.findAll({
        include: [{ model: Categoria, attributes: ["nombre"] }],
        order: [['fecha', 'DESC']]
    });
};

// Obtener sesión por ID
const getSesionById = async (id) => {
    return await Sesion.findByPk(id, {
        include: [{ model: Categoria, attributes: ["nombre"] }]
    });
};

// Obtener sesiones por ID de categoría
const getSesionesByCategoria = async (id_categoria) => {
    return await Sesion.findAll({
        where: { id_categoria },
        include: [{ model: Categoria, attributes: ["nombre"] }],
        order: [['fecha', 'DESC']]
    });
};

// Crear sesión
const createSesion = async (data) => {
    return await Sesion.create(data);
};

// Eliminar sesión
const deleteSesion = async (id) => {
    const deleted = await Sesion.destroy({ where: { id_sesion: id } });
    return deleted ? "Sesión eliminada correctamente" : "Sesión no encontrada";
};

module.exports = {
    getAllSesiones,
    getSesionById,
    getSesionesByCategoria,
    createSesion,
    deleteSesion
};
