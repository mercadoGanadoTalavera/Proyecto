const { Model, DataTypes } = require('sequelize');
const sequelize = require('../db');

class Sesion extends Model {}

Sesion.init(
    {
        id_sesion: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        fecha: {
            type: DataTypes.DATE,
            allowNull: false
        },
        id_categoria: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: 'categoria',
                key: 'id_categoria'
            }
        }
    },
    {
        sequelize,
        modelName: 'Sesion',
        tableName: 'sesion',
        timestamps: false
    }
);

module.exports = Sesion;
